# Note méthodologique complète — Méthode 1 (BVAR + Bridge equations + AR(4))

Ce document consolide, en un seul endroit, l'ensemble des méthodes de
sélection et des techniques de modélisation appliquées dans ce dossier —
à lire indépendamment du reste de la conversation.

---

## 1. Architecture générale

Adaptation du modèle GDPNow (Federal Reserve Bank d'Atlanta) à une logique
**offre** (production par branche d'activité, nomenclature HCP) plutôt que
demande. Trois briques, appliquées selon la couverture de chaque branche :

| Brique | Branches concernées | Rôle |
|---|---|---|
| **BVAR trimestriel** | Les 16 branches | Prévision de repli, prior bayésien Minnesota |
| **Bridge equations** | 8 branches disposant d'au moins un indicateur validé | Combine indicateur(s) d'activité et BVAR |
| **AR(4) pur** | 8 branches sans indicateur validé | Extrapolation de tendance uniquement |

---

## 2. Sélection des indicateurs — la cascade de 8 critères

Partant d'un pool de plus de 1200 séries candidates recensées, la sélection
s'effectue en cascade : chaque critère s'applique sur ce qui a survécu au
précédent.

| # | Critère | Seuil retenu | Justification |
|---|---|---|---|
| 1 | Fréquence | Mensuelle ou trimestrielle uniquement | Une série annuelle ne peut informer une prévision infra-annuelle |
| 2 | Longueur minimale | ≥ 24 observations | Nécessaire pour une régression fiable et un test hors-échantillon |
| 3 | Fraîcheur | ≤ 450 jours (mensuel) / ≤ 365 jours (trimestriel) | Une série ancienne n'informe pas le trimestre en cours ; le seuil trimestriel intègre le délai de publication habituel du HCP |
| 4 | Densité interne | ≥ 75 % de valeurs non manquantes | Un nombre élevé d'observations peut cacher de nombreux trous |
| 5 | **Pertinence statistique** | Test de Student sur r (α=0,10, bilatéral) **ET** \|r\| ≥ 0,15 | Voir section 3 — remplace un ancien seuil fixe non rigoureux |
| 6 | Cohérence du signe | Observé, non filtrant | Documenté (⚠️) mais pas éliminatoire — voir section 5 |
| 7 | Non-redondance | Corrélation croisée < 0,85 entre indicateurs retenus d'une même branche | Évite de compter deux fois le même signal économique |
| 8 | Cible unique par branche | Version la plus longue disponible (≥ 40 observations) | Élimine la redondance des ~26 variantes de VA par branche |

### 2.1 — Critère 5 en détail : pourquoi un test statistique plutôt qu'un seuil fixe

**Ancienne version** : seuil de magnitude fixe (\|r\| ≥ 0,25), quel que soit
le nombre d'observations. **Problème identifié** : une corrélation de 0,25
sur 10 points n'a rien à voir, statistiquement, avec une corrélation de
0,25 sur 100 points — le seuil fixe pénalisait à tort les séries longues
(où même une corrélation modeste est significative) et pouvait laisser
passer à tort les séries courtes (où il faudrait une corrélation bien plus
forte pour être fiable).

**Nouvelle version** : test de significativité classique sur le
coefficient de Pearson (inférence standard, ex. Wooldridge,
*Introductory Econometrics*, chapitre sur la régression simple) :

$$t = r\sqrt{\frac{n-2}{1-r^2}} \sim \text{Student}(n-2) \text{ sous } H_0: \rho=0$$

Retenu si \|t\| dépasse le seuil critique à 10 % bilatéral. Ce seuil de r
critique varie mécaniquement avec n : environ 0,34 pour n=24 (notre
minimum), 0,16 pour n=113 (notre maximum).

**Complément ajouté — plancher économique (\|r\| ≥ 0,15)** : le test de
significativité seul, sans plancher, laisse passer des corrélations
minuscules pour les séries à grand n (piège classique significativité
statistique ≠ pertinence économique). Le plancher évite ce travers sans
réintroduire l'insensibilité à n du seuil fixe d'origine.

**Une référence écartée à dessein** : Bai & Ng (2008) a été envisagée puis
écartée comme justification directe de ce critère — leur méthode de
seuillage (« hard thresholding ») sert à sélectionner des prédicteurs pour
la construction de **facteurs communs** (pertinent pour la Méthode 3, DFM),
pas pour une régression univariée simple comme la bridge equation. Le test
de Student utilisé ici est un résultat d'inférence de base, sans besoin
d'invoquer cette référence.

---

## 3. Traitement des valeurs manquantes — le jagged edge

**Principe rejeté explicitement** : la suppression pure des mois/trimestres
manquants (pratique initiale, corrigée sur demande explicite). Cette
suppression contredit la méthode de référence de Higgins (2014), qui
**prévoit** les points manquants plutôt que de les supprimer (étape des
« autorégressions augmentées par facteur » du papier GDPNow).

**Méthode retenue** : chaque indicateur est reconstruit sur un calendrier
complet (du premier au dernier point observé). Les trous sont comblés par
**lissage de Kalman** (`stats::arima` + `stats::KalmanSmooth`, base R) sur
un modèle AR ajusté en log-niveau — le même mécanisme conceptuel que la
littérature du jagged edge (Doz, Giannone & Reichlin, 2011), appliqué ici
indicateur par indicateur (pas de facteur commun, réservé à la Méthode 3).

Le même modèle sert aussi à la prévision du prochain point (au lieu d'un
AR(1) séparé ad hoc dans la version initiale) — un seul modèle pour les
deux usages, plus cohérent.

**Limite assumée** : ce mécanisme ne traite pas la saisonnalité. Un cas
concret l'a révélé (recettes touristiques, Hébergement-restauration) : un
AR non saisonnier peut confondre un creux saisonnier normal avec un
ralentissement conjoncturel réel. Non corrigé dans cette livraison — chantier
distinct proposé (SARIMA ou indicatrices de mois).

---

## 4. Le reste de l'architecture (BVAR, bridge, AR(4), agrégation)

- **BVAR trimestriel** : prior Minnesota par observations fictives
  (Litterman, 1986 ; Bańbura, Giannone & Reichlin, 2010), 5 retards,
  λ=0,15 (même valeur que le BVAR de composantes de quantité de GDPNow).
- **Bridge equations** : régression simple `Δlog(VA) ~ Δlog(indicateur)`
  par indicateur retenu, moyenne des prévisions individuelles, combinaison
  avec le BVAR par moindres carrés restreints (poids δ optimisé en
  échantillon, Higgins 2014 équation 8).
- **AR(4)** : pour les branches sans indicateur validé — même traitement
  que Higgins (2014) applique aux sous-composantes sans série mensuelle,
  ici appliqué à l'échelle de branches entières (différence d'échelle
  documentée et assumée).
- **Agrégation** : pondération par part de valeur ajoutée en volume
  (limite connue : non additive en toute rigueur, la vraie pondération
  Fisher/Törnqvist demanderait des séries à prix courants non disponibles
  pour les 16 branches).
- **Validation** : backtest en pseudo temps réel par troncature successive
  (8 derniers trimestres), repère AR(2), test de Diebold-Mariano (1995).

---

## 5. Liste complète des 51 séries retenues

⚠️ = signe de corrélation contre-intuitif (12 séries sur 51, soit 23,5 % —
en hausse par rapport aux 17 % observés sous l'ancien seuil fixe, cohérent
avec le risque de sur-inclusion à grand n mentionné en section 2.1).
Conservées malgré ce signal car le critère 6 n'est pas éliminatoire (voir
tableau des critères) — à examiner individuellement avant tout usage en
production, en particulier les 8 séries de la Pêche concernées.

| Branche | Indicateur | Fréquence | r | p-value | n | Source |
|---|---|---|---|---|---|---|
| Pêche | RKOUNTE ⚠️ | mensuel | -0.335 | 0.010 | 157 | Débarquements des produits de la pêche c |
| Pêche | AINBIDA | mensuel | +0.398 | 0.011 | 155 | Débarquements des produits de la pêche c |
| Pêche | ESSAOUIRA ⚠️ | mensuel | -0.283 | 0.025 | 173 | Débarquements des produits de la pêche c |
| Pêche | DAKHLA (STOCK C) ⚠️ | mensuel | -0.263 | 0.037 | 172 | Débarquements des produits de la pêche c |
| Pêche | TARFAYA ⚠️ | mensuel | -0.252 | 0.046 | 171 | Débarquements des produits de la pêche c |
| Pêche | MOHAMMEDIA ⚠️ | mensuel | -0.250 | 0.048 | 172 | Débarquements des produits de la pêche c |
| Pêche | IMI OUADDAR ⚠️ | mensuel | -0.236 | 0.065 | 173 | Débarquements des produits de la pêche c |
| Pêche | ATLANTIQUE ⚠️ | mensuel | -0.232 | 0.068 | 173 | Débarquements des produits de la pêche c |
| Pêche | POISSON BLANC ⚠️ | mensuel | -0.220 | 0.080 | 179 | Débarquements des produits de la pêche c |
| Pêche | SID ELGHAZI ⚠️ | mensuel | -0.221 | 0.082 | 173 | Débarquements des produits de la pêche c |
| Pêche | Comptes débiteurs et crédits de trésorerie — Pêche (MDH ⚠️ | trimestriel | -0.198 | 0.084 | 78 | Bank Al-Maghrib |
| Pêche | JEBHA ⚠️ | mensuel | -0.211 | 0.097 | 173 | Débarquements des produits de la pêche c |
| Industrie d'extraction | IPM — Autres industries extractives | trimestriel | +0.425 | 0.006 | 41 | Manar-Stat (Indice production minière, b |
| Industrie de transformation | IPI — Métallurgie | trimestriel | +0.727 | 0.000 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication d’autres produits minéraux non métall | trimestriel | +0.710 | 0.000 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | Taux d’Utilisation des Capacités | mensuel | +0.565 | 0.000 | 188 | Manar-Stat (Ministere de l'Economie et d |
| Industrie de transformation | IPI — Travail du bois et fabrication d’articles en bois | trimestriel | +0.638 | 0.000 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de produits métalliques, à l’exclusio | trimestriel | +0.615 | 0.000 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Réparation et installation de machines et équipem | trimestriel | +0.608 | 0.000 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de machines et équipements n.c.a. | trimestriel | +0.506 | 0.001 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de textiles | trimestriel | +0.489 | 0.001 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Industrie automobile | trimestriel | +0.481 | 0.002 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Industrie d’habillement | trimestriel | +0.473 | 0.002 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de produits à base de tabac | trimestriel | +0.466 | 0.002 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de boissons | trimestriel | +0.453 | 0.003 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication d’équipements électriques | trimestriel | +0.326 | 0.040 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de meubles | trimestriel | +0.305 | 0.056 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Industrie pharmaceutique | trimestriel | +0.297 | 0.063 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Fabrication de produits en caoutchouc et en plast | trimestriel | +0.287 | 0.072 | 41 | Manar-Stat (Indice production industriel |
| Industrie de transformation | IPI — Industrie du cuir et de la chaussure (à l’excepti | trimestriel | +0.276 | 0.084 | 41 | Manar-Stat (Indice production industriel |
| Électricité, gaz, eau | Production et distribution d’électricité | trimestriel | +0.613 | 0.000 | 41 | Indice de production énergétique base 20 |
| Électricité, gaz, eau | - Solde des échanges d'énergie (Espagne-Algérie) : | mensuel | +0.493 | 0.004 | 130 | energie.csv |
| Électricité, gaz, eau | dont Production de source renouvelable (éolien) | mensuel | +0.545 | 0.007 | 72 | energie.csv |
| Électricité, gaz, eau | Petcoke | mensuel | +0.192 | 0.054 | 304 | Consommation de l'ONEE en combustibles ( |
| Immobilier | Crédits aux promoteurs immobiliers (1) | mensuel | +0.365 | 0.000 | 294 | 12- Ventilation du crédit bancaire par o |
| Hébergement-restauration | Recettes touristiques (mensuel) | mensuel | +0.360 | 0.000 | 381 | Manar-Stat |
| Hébergement-restauration | Comptes débiteurs et crédits de trésorerie — Hébergemen ⚠️ | trimestriel | -0.222 | 0.052 | 78 | Bank Al-Maghrib |
| Finances et assurances | Secteur privé | mensuel | +0.407 | 0.000 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Autres(2) | mensuel | +0.326 | 0.001 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Sociétés non financières privées | mensuel | +0.310 | 0.002 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Comptes débiteurs et crédits de trésorerie | mensuel | +0.301 | 0.003 | 294 | 12- Ventilation du crédit bancaire par o |
| Finances et assurances | Autres sociétés financières | mensuel | +0.288 | 0.004 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Particuliers et Marocains Résidant à l'Etranger | mensuel | +0.286 | 0.004 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Crédit bancaire Activités financières (MDH) | trimestriel | +0.297 | 0.009 | 78 | Bank Al-Maghrib |
| Finances et assurances | Crédit bancaire | mensuel | +0.258 | 0.027 | 222 | Bank Al-Maghrib |
| Finances et assurances | Crédits à l'équipement | mensuel | +0.215 | 0.035 | 294 | 12- Ventilation du crédit bancaire par o |
| Finances et assurances | ISBLSM | mensuel | +0.208 | 0.041 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Autres secteurs résidents | mensuel | +0.195 | 0.055 | 294 | 13- Ventilation du crédit bancaire par s |
| Finances et assurances | Dépôts à vue auprés des banques | mensuel | +0.222 | 0.078 | 196 | BDD SECTORIEL (source institutionnelle c |
| Finances et assurances | Masse monétaire (M3) | mensuel | +0.221 | 0.080 | 196 | BDD SECTORIEL (source institutionnelle c |
| Construction | Vente de ciment (1000tonnes) | mensuel | +0.216 | 0.022 | 373 | Manar-Stat (Ministere de l'Economie et d |

---

## 6. Références de littérature mobilisées

| Référence | Usage dans ce document |
|---|---|
| Higgins, P. (2014). *GDPNow: A Model for GDP "Nowcasting"*. FRB Atlanta WP 2014-7 | Architecture générale, bridge equations, traitement des composantes sans indicateur, jagged edge |
| Litterman, R. (1986). *Forecasting with Bayesian Vector Autoregressions* | Prior Minnesota du BVAR |
| Bańbura, M., Giannone, D. & Reichlin, L. (2010). *Large Bayesian VARs*. J. of Applied Econometrics 25(1) | Méthode des observations fictives |
| Doz, C., Giannone, D. & Reichlin, L. (2011). *A Two-Step Estimator for Large Approximate Dynamic Factor Models* | Mécanisme conceptuel du jagged edge (lissage de Kalman) |
| Diebold, F.X. & Mariano, R.S. (1995). *Comparing Predictive Accuracy* | Test de significativité de l'écart de précision (backtest) |
| Bai, J. & Ng, S. (2008). *Forecasting Economic Time Series Using Targeted Predictors*. J. of Econometrics 146(2) | Discutée puis écartée comme justification du critère 5 (pertinente pour un modèle à facteurs, pas pour une bridge equation univariée) |
| Wooldridge, J. — *Introductory Econometrics* (tout manuel équivalent) | Test de significativité standard sur un coefficient de corrélation (critère 5) |

---

## 7. Limites assumées, non corrigées dans cette livraison

1. Saisonnalité non traitée (section 3)
2. Poids d'agrégation approximatifs, non additifs en toute rigueur (section 4)
3. 12 séries sur 51 à signe contre-intuitif, non filtrées (section 5)
4. Absence de poids de sous-branche pour la moyenne des prévisions bridge
   (équation 7 de Higgins non reproduite, faute de données de valeur ajoutée
   nominale par sous-branche)
5. 8 branches sur 16 toujours sans indicateur (AR(4) pur)
